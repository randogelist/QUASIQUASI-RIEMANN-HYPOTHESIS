import AWPIRH.ThetaEntire
