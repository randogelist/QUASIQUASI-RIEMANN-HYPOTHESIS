# RH POSITIVITY-PREMISE — Lean v0.1.1 FASTSTART

This package formalizes the defect bounds and the **conditional equivalence**
between POSITIVITY-PREMISE and Mathlib's literal `RiemannHypothesis`.
It does not prove POSITIVITY-PREMISE for the Riemann zeta function.
There is no simple-zero assumption.

## The exact premise

For the **same fixed** real numbers `C` and `c1`, the definition is

```lean
def PositivityPremise (C c1 : ℝ) : Prop :=
  ∀ T : ℝ, 1 ≤ T → 0 ≤ C ∧ C ≤ 3 * c1 / (4 * T ^ 2)
```

`positivityPremise_iff_eq_zero` proves this is equivalent to `C = 0` when
`0 ≤ c1`. The proof is algebraic: if `C > 0`, it uses the finite height
`T = 1 + 3*c1/C` to contradict the upper bound.

The fixed-height estimate at the first off-line height `tau` does **not**
imply RH. A fixed positive scalar satisfying one such estimate is exhibited
by `fixed_height_counterexample`.

## Exact kernel and bounds

For a zero `rho = 1/2 + delta + i*gamma`, with positive multiplicity `m`,

```text
d(m,delta,gamma) =
  m*delta^2*(3*gamma^2 + delta^2) /
    (gamma^2*(gamma^2 + delta^2)^2).
```

The kernel module proves, for `gamma > 0`,

```text
m/gamma^2 - m*(gamma^2-delta^2)/(gamma^2+delta^2)^2 = d,
0 <= d,
d = 0  <->  delta = 0                 (m > 0),
d <= 3*m*delta^2/gamma^4.
```

With `delta^2 <= 1/4`, it also proves

```text
3*m*delta^2/(gamma^2+1/4)^2 <= d <= 3*m/(4*gamma^4).
```

The series layer defines

```text
c1 = sum_i m_i/gamma_i^2,
C = sum_i d_i,
trace = sum_i m_i*(gamma_i^2-delta_i^2)/(gamma_i^2+delta_i^2)^2.
```

It proves `C = c1 - trace`, `C >= 0`, and

```text
C = 0 <-> every delta_i = 0.
```

A distinct reflected pair at height `tau`, with deviations `delta` and
`-delta` and multiplicity `m`, supplies the lower bound

```text
6*m*delta^2/(tau^2+1/4)^2 <= C.
```

When every off-line zero has height at least `tau > 0`, the upper bound is

```text
C <= 3*c1/(4*tau^2).
```

The tail module keeps this conditional total bound separate from the
arbitrary-cutoff tail bound. Prefixes and tails use `gamma <= T` and
`T < gamma`, respectively, so zeros at the cutoff are counted in the prefix.

## Literal zeta and the remaining analytic inputs

`ZeroData` contains coordinates, positive natural-number multiplicities,
the strip bound, and summability of the inverse-square and defect series.
Summability is essential: Lean's real `tsum` is totalized, and a divergent
series must not be mistaken for a zero defect.

`ZetaBinding D` supplies an actual complex zero for each index, identifies
its coordinates with those in `D`, and covers every nontrivial zeta zero
up to conjugation. Its nontrivial-zero predicate is exactly the one in
Mathlib's RH definition.

`CanonicalZetaBinding D` additionally requires an injective enumeration
and multiplicities equal to `analyticOrderNatAt riemannZeta`.
Neither binding is constructed in this package.

The canonical xi function is defined from Mathlib's entire completion:

```lean
def canonicalXi (s : ℂ) : ℂ :=
  (1 + s * (s - 1) * completedRiemannZeta₀ s) / 2

def centerCurvature : ℝ :=
  (deriv (deriv canonicalXi) (1 / 2) /
    (2 * canonicalXi (1 / 2))).re
```

The central trace identity is an explicit input:

```lean
def TraceIdentification (D : ZeroData ι) : Prop :=
  centerCurvature = D.trace
```

With it, the package proves `C = c1 - centerCurvature`. It does not
independently establish the Hadamard trace identity, evaluate the curvature,
construct the canonical zero data, or prove the quantified positivity premise.
These are visible theorem arguments and structure fields, not added axioms.

## Main theorem signatures

Within namespace `PositivityPremise`:

```lean
POSITIVITY_PREMISE_IFF_RH (B : ZetaBinding D) :
  PositivityPremise D.C D.c1 ↔ RiemannHypothesis

CURVATURE_POSITIVITY_PREMISE_IFF_RH
    (B : ZetaBinding D) (htrace : TraceIdentification D) :
  PositivityPremise (D.c1 - centerCurvature) D.c1 ↔ RiemannHypothesis

CANONICAL_POSITIVITY_PREMISE_IFF_RH
    (B : CanonicalZetaBinding D) (htrace : TraceIdentification D) :
  PositivityPremise (D.c1 - centerCurvature) D.c1 ↔ RiemannHypothesis

CENTRAL_CURVATURE_EQUALITY_IFF_RH
    (B : ZetaBinding D) (htrace : TraceIdentification D) :
  D.c1 = centerCurvature ↔ RiemannHypothesis
```

Thus the exact scalar closure criterion is obtained under the displayed
analytic identification hypotheses. The package does not hide an RH
equivalence inside an assumed field.

## Fast Windows startup

Run `run.cmd`. It calls the installed native Lean executable directly,
reuses the existing Mathlib cache, and defaults to 16 compiler threads.
It invokes no Lake, network download, Python, PowerShell, or WSL.
All seven local Lean sources are still checked, including the axiom audit.

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "RH_POSITIVITY_PREMISE_LEAN_v0_1_1_FASTSTART.zip" && call "RH_POSITIVITY_PREMISE_LEAN_v0_1_1_FASTSTART\run.cmd"
```

Compiler selection, in order:

1. `AWPIRH_LEAN_EXE`, when supplied.
2. `LEAN_EXE`, when supplied.
3. Lean 4.33.0 under `ELAN_HOME` or `%USERPROFILE%\.elan`.

An explicit `MATHLIB_CACHE_ROOT` selects either a cached project root or a
Mathlib checkout. Otherwise the runner tries the package's own cache,
`%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1`, the same project
under Downloads, then the sibling v0.1.0 positivity package's cache.
No recursive disk search is performed.

The runner checks ten targeted Mathlib imports; `Mathlib.olean` is not needed.
It includes both project-level and nested Mathlib dependency caches.
Missing or incompatible dependencies cause a clear failure without an
automatic download or rebuild. Explicit overrides never silently fall back.

If needed, set the cache location once in your CMD session:

```cmd
set "MATHLIB_CACHE_ROOT=C:\path\to\your\existing\cached-project"
```

Outputs go to `.native-build`. Results are recorded in `run-build.log` and
`run-audit.log`. The mathematical sources are byte-identical to verified v0.1.0.
The Windows launcher was statically reviewed; native Windows execution must
be checked on the user's machine.

## Optional standard Lake build

- Lean: `leanprover/lean4:v4.33.0`.
- Mathlib: `db584cd6d46c92f209a44c0f1c829460d327499d` (v4.33.0).
- Dependencies: Mathlib and its standard dependencies only; none of the
  uploaded research packages is required.

With Elan/Lake installed, on first use:

```bash
lake update
lake exe cache get
lake build
lake env lean Audit.lean
```

After dependency setup, `./run.sh` builds and prints the audit using Lake.
The Windows `run.cmd` uses the independent fast-cache path described above.
The archive contains sources, dependency pins, and the recorded validation
report; it omits platform-dependent `.olean` files and the Mathlib cache.

The included audit prints the main declarations and their logical axioms.
Standard Lean foundations (`propext`, `Classical.choice`, `Quot.sound`) are
distinct from user-supplied analytic hypotheses, which appear in theorem
types. No `sorry`, `admit`, custom axiom, or native-evaluation proof is used.

See `audit/BUILD_REPORT.md` and `audit/axioms.log` for the actual verification
performed for this release.
