import PositivityPremise.Series

/-!
# Height bounds and the prefix–tail decomposition

Every estimate follows from the defect kernel and the explicit summability
fields of `ZeroData`. The height-gap hypothesis only concerns off-line zeros.
-/

noncomputable section

namespace PositivityPremise.ZeroData

variable {ι : Type*} (D : PositivityPremise.ZeroData ι)

/-- The pointwise defect is dominated by inverse-square mass above a height. -/
theorem contribution_le_height_mass (i : ι) {T : ℝ} (hT : 0 < T)
    (hi : T ≤ D.gamma i) :
    D.contribution i ≤ (3 / (4 * T ^ 2)) * D.mass i := by
  have hg := D.gamma_pos i
  have hsq : T ^ 2 ≤ D.gamma i ^ 2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hi)
      (show 0 ≤ D.gamma i + T by positivity)]
  have hden : 4 * T ^ 2 ≤ 4 * D.gamma i ^ 2 := by linarith
  have hcoef : 3 / (4 * D.gamma i ^ 2) ≤ 3 / (4 * T ^ 2) :=
    div_le_div_of_nonneg_left (by norm_num) (by positivity) hden
  calc
    D.contribution i ≤ 3 * (D.multiplicity i : ℝ) / (4 * D.gamma i ^ 4) :=
      PositivityPremise.defect_upper_bound (le_of_lt (D.multiplicity_real_pos i))
        hg (D.strip i)
    _ = (3 / (4 * D.gamma i ^ 2)) * D.mass i := by
      unfold mass
      ring
    _ ≤ (3 / (4 * T ^ 2)) * D.mass i :=
      mul_le_mul_of_nonneg_right hcoef (D.mass_nonneg i)

/-- If every off-line zero has height at least `tau`, the full defect is small. -/
theorem total_upper_bound {tau : ℝ} (htau : 0 < tau)
    (hgap : ∀ i, D.delta i ≠ 0 → tau ≤ D.gamma i) :
    D.C ≤ 3 * D.c1 / (4 * tau ^ 2) := by
  have hp : ∀ i, D.contribution i ≤ (3 / (4 * tau ^ 2)) * D.mass i := by
    intro i
    by_cases hi : D.delta i = 0
    · have hz : D.contribution i = 0 :=
        (PositivityPremise.defect_eq_zero_iff (D.multiplicity_real_pos i)
          (D.gamma_pos i)).2 hi
      rw [hz]
      exact mul_nonneg (by positivity) (D.mass_nonneg i)
    · exact D.contribution_le_height_mass i htau (hgap i hi)
  have hm : Summable D.mass := D.summable_mass
  have hd : Summable D.contribution := D.summable_defect
  have hs := hd.tsum_le_tsum hp (hm.mul_left (3 / (4 * tau ^ 2)))
  calc
    D.C ≤ ∑' i, (3 / (4 * tau ^ 2)) * D.mass i := hs
    _ = (3 / (4 * tau ^ 2)) * D.c1 := by rw [tsum_mul_left]; rfl
    _ = 3 * D.c1 / (4 * tau ^ 2) := by ring

/-- Defect at ordinates at most `T`; the endpoint belongs to the prefix. -/
def «prefix» (T : ℝ) : ℝ :=
  ∑' i, ({i | D.gamma i ≤ T} : Set ι).indicator D.contribution i

/-- Defect at ordinates strictly above `T`. -/
def tail (T : ℝ) : ℝ :=
  ∑' i, ({i | T < D.gamma i} : Set ι).indicator D.contribution i

/-- Inverse-square zero mass strictly above `T`. -/
def tailMass (T : ℝ) : ℝ :=
  ∑' i, ({i | T < D.gamma i} : Set ι).indicator D.mass i

theorem summable_prefix (T : ℝ) :
    Summable (({i | D.gamma i ≤ T} : Set ι).indicator D.contribution) :=
  D.summable_defect.indicator _

theorem summable_tail (T : ℝ) :
    Summable (({i | T < D.gamma i} : Set ι).indicator D.contribution) :=
  D.summable_defect.indicator _

theorem summable_tailMass (T : ℝ) :
    Summable (({i | T < D.gamma i} : Set ι).indicator D.mass) :=
  D.summable_mass.indicator _

theorem C_eq_prefix_add_tail (T : ℝ) : D.C = D.prefix T + D.tail T := by
  classical
  unfold C «prefix» tail
  rw [← (D.summable_prefix T).tsum_add (D.summable_tail T)]
  apply tsum_congr
  intro i
  by_cases hi : D.gamma i ≤ T
  · simp [Set.indicator, hi, not_lt.mpr hi]
  · simp [Set.indicator, hi, lt_of_not_ge hi]

theorem prefix_nonneg (T : ℝ) : 0 ≤ D.prefix T := by
  apply tsum_nonneg
  intro i
  exact Set.indicator_nonneg (fun j _ => D.contribution_nonneg j) i

theorem tail_nonneg (T : ℝ) : 0 ≤ D.tail T := by
  apply tsum_nonneg
  intro i
  exact Set.indicator_nonneg (fun j _ => D.contribution_nonneg j) i

theorem tailMass_nonneg (T : ℝ) : 0 ≤ D.tailMass T := by
  apply tsum_nonneg
  intro i
  exact Set.indicator_nonneg (fun j _ => D.mass_nonneg j) i

theorem tailMass_le_c1 (T : ℝ) : D.tailMass T ≤ D.c1 := by
  classical
  have hm : Summable D.mass := D.summable_mass
  apply (D.summable_tailMass T).tsum_le_tsum _ hm
  intro i
  by_cases hi : T < D.gamma i
  · simp [Set.indicator, hi]
  · simpa [Set.indicator, hi] using D.mass_nonneg i

/-- The sharper tail estimate retains only the mass above the cutoff. -/
theorem tail_upper_bound_mass {T : ℝ} (hT : 0 < T) :
    D.tail T ≤ 3 * D.tailMass T / (4 * T ^ 2) := by
  classical
  have hp : ∀ i,
      ({i | T < D.gamma i} : Set ι).indicator D.contribution i ≤
        (3 / (4 * T ^ 2)) * ({i | T < D.gamma i} : Set ι).indicator D.mass i := by
    intro i
    by_cases hi : T < D.gamma i
    · simpa [Set.indicator, hi] using D.contribution_le_height_mass i hT hi.le
    · simp [Set.indicator, hi]
  have hs := (D.summable_tail T).tsum_le_tsum hp
    ((D.summable_tailMass T).mul_left (3 / (4 * T ^ 2)))
  calc
    D.tail T ≤ ∑' i, (3 / (4 * T ^ 2)) *
        ({i | T < D.gamma i} : Set ι).indicator D.mass i := hs
    _ = (3 / (4 * T ^ 2)) * D.tailMass T := by rw [tsum_mul_left]; rfl
    _ = 3 * D.tailMass T / (4 * T ^ 2) := by ring

theorem tail_upper_bound {T : ℝ} (hT : 0 < T) :
    D.tail T ≤ 3 * D.c1 / (4 * T ^ 2) := by
  calc
    D.tail T ≤ 3 * D.tailMass T / (4 * T ^ 2) := D.tail_upper_bound_mass hT
    _ ≤ 3 * D.c1 / (4 * T ^ 2) :=
      div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_left (D.tailMass_le_c1 T) (by norm_num)) (by positivity)

/-- A first off-line reflected pair gives both explicit bounds. The existence
and reflection data of such a pair are hypotheses, not simplicity assumptions. -/
theorem first_off_bounds (i j : ι) {tau : ℝ} (htau : 0 < tau)
    (hij : i ≠ j) (hoff : D.delta i ≠ 0)
    (hm : D.multiplicity j = D.multiplicity i)
    (hg : D.gamma j = D.gamma i) (hd : D.delta j = -D.delta i)
    (hi : D.gamma i = tau)
    (hgap : ∀ k, D.delta k ≠ 0 → tau ≤ D.gamma k) :
    0 < D.C ∧
      6 * (D.multiplicity i : ℝ) * D.delta i ^ 2 /
        (tau ^ 2 + 1 / 4) ^ 2 ≤ D.C ∧
      D.C ≤ 3 * D.c1 / (4 * tau ^ 2) := by
  refine ⟨D.C_pos_of_offLine i hoff, ?_, D.total_upper_bound htau hgap⟩
  simpa only [hi] using D.reflected_pair_lower_bound i j hij hm hg hd

end PositivityPremise.ZeroData
