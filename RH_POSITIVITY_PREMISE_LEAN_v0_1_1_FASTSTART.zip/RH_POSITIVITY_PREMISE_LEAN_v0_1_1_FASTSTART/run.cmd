@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "RUN_EXIT=1"
set "RUN_PUSHED=0"
set "RUN_STEP=Opening the package"
pushd "%~dp0"
if errorlevel 1 goto :failed
set "RUN_PUSHED=1"
> "run-build.log" echo PACKAGE=RH_POSITIVITY_PREMISE_LEAN_v0_1_1_FASTSTART
if errorlevel 1 goto :failed
> "run-audit.log" echo Audit has not run yet.
if errorlevel 1 goto :failed
echo PACKAGE=RH_POSITIVITY_PREMISE_LEAN_v0_1_1_FASTSTART
echo RUNNER=NATIVE_WINDOWS_LEAN_433_FASTCACHE
echo NETWORK=NOT_USED
echo LAKE=NOT_USED
echo PYTHON=NOT_USED
echo POWERSHELL=NOT_USED
echo WSL=NOT_USED

rem Use the native executable, never an elan shim that might download a toolchain.
if defined AWPIRH_LEAN_EXE set "LEAN_EXE=%AWPIRH_LEAN_EXE%"
if defined LEAN_EXE goto :compiler_selected
if defined ELAN_HOME goto :compiler_elan_home
set "LEAN_EXE=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0\bin\lean.exe"
goto :compiler_selected
:compiler_elan_home
set "LEAN_EXE=%ELAN_HOME%\toolchains\leanprover--lean4---v4.33.0\bin\lean.exe"
:compiler_selected
set "RUN_STEP=Checking native Lean 4.33.0"
if not exist "%LEAN_EXE%" goto :missing_lean
"%LEAN_EXE%" --version > "lean_version.log" 2>&1
set "RUN_EXIT=%errorlevel%"
if not "%RUN_EXIT%"=="0" goto :failed
type "lean_version.log"
type "lean_version.log" >> "run-build.log"
findstr /L /C:"version 4.33.0," "lean_version.log" >nul
if errorlevel 1 goto :wrong_version
"%LEAN_EXE%" --print-prefix > "lean_prefix.log" 2>&1
set "RUN_EXIT=%errorlevel%"
if not "%RUN_EXIT%"=="0" goto :failed
set "TOOLCHAIN="
set /p "TOOLCHAIN=" < "lean_prefix.log"
if not defined TOOLCHAIN goto :missing_lean
if not exist "%TOOLCHAIN%\lib\lean\Init.olean" goto :missing_lean

rem Deterministic cache probes; an explicit override never silently falls back.
set "RUN_STEP=Locating the existing Mathlib cache"
if defined MATHLIB_CACHE_ROOT goto :cache_override
set "CACHE_ROOT=%CD%"
call :try_cache
if not errorlevel 1 goto :cache_selected
set "CACHE_ROOT=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
call :try_cache
if not errorlevel 1 goto :cache_selected
set "CACHE_ROOT=%USERPROFILE%\Downloads\awpi_phi_rh_lean_sieved_v0_1_1"
call :try_cache
if not errorlevel 1 goto :cache_selected
set "CACHE_ROOT=%~dp0..\RH_POSITIVITY_PREMISE_LEAN_v0_1_0"
call :try_cache
if not errorlevel 1 goto :cache_selected
goto :missing_cache
:cache_override
set "CACHE_ROOT=%MATHLIB_CACHE_ROOT%"
call :try_cache
if errorlevel 1 goto :missing_cache
:cache_selected
echo MATHLIB_CACHE=READY
echo CACHE_ROOT="%CACHE_ROOT%"
echo MATHLIB_ROOT="%MATHLIB_ROOT%"
echo FULL_MATHLIB_UMBRELLA_IMPORT=NO
>> "run-build.log" echo CACHE_ROOT="%CACHE_ROOT%"
>> "run-build.log" echo MATHLIB_ROOT="%MATHLIB_ROOT%"

rem Reuse dependency artifacts only; every project theorem is compiled afresh.
set "BUILD_DIR=%CD%\.native-build"
set "RUN_STEP=Preparing the local output directory"
if not exist "%BUILD_DIR%\PositivityPremise" mkdir "%BUILD_DIR%\PositivityPremise"
if not exist "%BUILD_DIR%\PositivityPremise" goto :failed
set "LEAN_PATH=%BUILD_DIR%;%MATHLIB_ROOT%\.lake\build\lib\lean"
for /d %%D in ("%CACHE_ROOT%\.lake\packages\*") do (
  set "CACHE_PACKAGE=%%~fD"
  call :append_cache
)
for /d %%D in ("%MATHLIB_ROOT%\.lake\packages\*") do (
  set "CACHE_PACKAGE=%%~fD"
  call :append_cache
)
set "LEAN_PATH=%LEAN_PATH%;%TOOLCHAIN%\lib\lean"
set "LEAN_SYSROOT=%TOOLCHAIN%"
set "PATH=%TOOLCHAIN%\bin;%PATH%"
if not defined LEAN_JOBS set "LEAN_JOBS=16"
set "LEAN_NUM_THREADS=%LEAN_JOBS%"
echo LEAN_JOBS=%LEAN_JOBS%
echo LOCAL_SOURCE_COUNT=7

set "RUN_STEP=Scanning project proof sources"
findstr /S /N /I /R /C:"\<sorry\>" /C:"\<admit\>" /C:"^[ ]*axiom " PositivityPremise\*.lean PositivityPremise.lean Audit.lean > "source_scan.log" 2>&1
set "RUN_EXIT=%errorlevel%"
if "%RUN_EXIT%"=="0" goto :source_fail
if not "%RUN_EXIT%"=="1" goto :failed
echo PROJECT_SOURCE_SCAN=PASS

set "RUN_STEP=Reading the source dependency order"
if not exist "compile-order.txt" goto :failed
for /f "usebackq delims=" %%M in ("compile-order.txt") do (
  call :compile "%%M"
  if errorlevel 1 goto :failed
)

rem Audit is the seventh Lean source. Its elaboration prints the axiom audit.
set "RUN_STEP=Compiling and checking the audit"
echo AUDIT_START=Audit.lean
"%LEAN_EXE%" -j%LEAN_JOBS% -o "%BUILD_DIR%\Audit.olean" Audit.lean > "run-audit.log" 2>&1
set "RUN_EXIT=%errorlevel%"
if not "%RUN_EXIT%"=="0" goto :audit_fail
findstr /L /C:"sorryAx" "run-audit.log" >nul
set "RUN_EXIT=%errorlevel%"
if "%RUN_EXIT%"=="0" goto :audit_fail
if not "%RUN_EXIT%"=="1" goto :audit_fail
findstr /L /C:"depends on axioms:" "run-audit.log" > "axiom_dependencies.log"
if errorlevel 1 goto :audit_fail
findstr /L /V /C:"depends on axioms: [propext, Classical.choice, Quot.sound]" "axiom_dependencies.log" > "unexpected_axioms.log"
set "RUN_EXIT=%errorlevel%"
if "%RUN_EXIT%"=="0" goto :audit_fail
if not "%RUN_EXIT%"=="1" goto :audit_fail
findstr /L /C:"'PositivityPremise.CANONICAL_POSITIVITY_PREMISE_IFF_RH' depends on axioms:" "axiom_dependencies.log" >nul
if errorlevel 1 goto :audit_fail

set "RUN_EXIT=0"
echo AUDIT_PASS=Audit.lean
echo AXIOM_AUDIT=STANDARD_LOGICAL_AXIOMS_ONLY
echo SORRYAX=NONE
echo DEFECT_BOUNDS=PROVED
echo POSITIVITY_PREMISE_RH_EQUIVALENCE=PROVED_UNDER_EXPLICIT_ANALYTIC_INPUTS
echo POSITIVITY_PREMISE=UNPROVED
echo ANALYTIC_BINDING_AND_TRACE=EXPLICIT_INPUTS
echo SIMPLICITY_ASSUMPTION=NOT_USED
echo PROJECT_BUILD=PASS
echo RUN=PASS
>> "run-build.log" echo PROJECT_BUILD=PASS
echo Logs: run-build.log and run-audit.log
goto :finish

:try_cache
set "MATHLIB_ROOT=%CACHE_ROOT%\.lake\packages\mathlib"
if exist "%MATHLIB_ROOT%\lean-toolchain" goto :check_cache
set "MATHLIB_ROOT=%CACHE_ROOT%"
:check_cache
if not exist "%MATHLIB_ROOT%\lean-toolchain" exit /b 1
findstr /L /X /C:"leanprover/lean4:v4.33.0" "%MATHLIB_ROOT%\lean-toolchain" >nul
if errorlevel 1 exit /b 1
if not exist "mathlib-imports.txt" exit /b 1
for /f "usebackq delims=" %%M in ("mathlib-imports.txt") do (
  if not exist "%MATHLIB_ROOT%\.lake\build\lib\lean\%%M" exit /b 1
)
exit /b 0

:append_cache
if exist "%CACHE_PACKAGE%\.lake\build\lib\lean" set "LEAN_PATH=%LEAN_PATH%;%CACHE_PACKAGE%\.lake\build\lib\lean"
exit /b 0

:compile
set "RUN_SRC=%~1"
set "RUN_STEP=Compiling %~1"
set "RUN_OUT=%BUILD_DIR%\%RUN_SRC:.lean=.olean%"
set "RUN_EXIT=1"
if not exist "%RUN_SRC%" exit /b 1
if exist "%RUN_OUT%" del /q "%RUN_OUT%"
if exist "%RUN_OUT%" exit /b 1
echo COMPILE_START=%RUN_SRC%
>> "run-build.log" echo COMPILE_START=%RUN_SRC%
"%LEAN_EXE%" -j%LEAN_JOBS% -o "%RUN_OUT%" "%RUN_SRC%" > "last_compile.log" 2>&1
set "RUN_EXIT=%errorlevel%"
type "last_compile.log"
type "last_compile.log" >> "run-build.log"
if not "%RUN_EXIT%"=="0" exit /b 1
if not exist "%RUN_OUT%" (
  set "RUN_EXIT=1"
  exit /b 1
)
echo COMPILE_PASS=%RUN_SRC%
>> "run-build.log" echo COMPILE_PASS=%RUN_SRC%
exit /b 0

:missing_lean
echo LEAN_EXE_FOUND=FAIL
echo Set AWPIRH_LEAN_EXE or LEAN_EXE to native Lean 4.33.0 lean.exe.
set "RUN_EXIT=2"
goto :failed
:wrong_version
echo LEAN_VERSION_CHECK=FAIL_EXPECTED_4.33.0
set "RUN_EXIT=3"
goto :failed
:missing_cache
echo MATHLIB_CACHE=NOT_FOUND_OR_INCOMPLETE
echo Set MATHLIB_CACHE_ROOT to your cached project root or Mathlib checkout.
echo No download or dependency rebuild has been attempted.
set "RUN_EXIT=4"
goto :failed
:source_fail
type "source_scan.log"
echo PROJECT_SOURCE_SCAN=FAIL
set "RUN_EXIT=5"
goto :failed
:audit_fail
type "run-audit.log"
if exist "unexpected_axioms.log" type "unexpected_axioms.log"
set "RUN_EXIT=6"
goto :failed
:failed
if "%RUN_EXIT%"=="0" set "RUN_EXIT=1"
echo PROJECT_BUILD=FAIL
echo FAILED_STAGE=%RUN_STEP%
echo EXIT_CODE=%RUN_EXIT%
if "%RUN_PUSHED%"=="1" echo Logs: "%CD%\run-build.log" and "%CD%\run-audit.log"
:finish
if "%RUN_PUSHED%"=="1" popd
endlocal & exit /b %RUN_EXIT%
