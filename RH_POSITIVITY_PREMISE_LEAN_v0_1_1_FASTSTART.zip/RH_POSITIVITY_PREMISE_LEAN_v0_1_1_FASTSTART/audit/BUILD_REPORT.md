# Verification report — 2026-10-19, FASTSTART revision

The seven Lean source files in v0.1.1 are byte-identical to those verified
for v0.1.0 below. Their hashes were checked against `validation.json`.
The changes are the native Windows fast-cache launcher, startup configuration,
and documentation. Native Windows execution was not available here; launcher
validation is static. `runner-checks.json` records the additional checks.

**Status: PASS.** Five mathematical modules, the root import module, and
`Audit.lean` were freshly checked with the actual Lean compiler and Mathlib.

## Exact environment

- Lean 4.33.0, Linux x86-64, release build.
- Lean commit: `d8b18978322de05a8f3dba51ef03cf5461676c17`.
- Mathlib commit: `db584cd6d46c92f209a44c0f1c829460d327499d`.
- The Mathlib checkout had a clean tracked working tree.
- Actual Mathlib compiled dependencies were used, with targeted imports.
- Each project module was compiled from its current source into a fresh,
  isolated `.validation-build` directory, in dependency order.
- `LEAN_PATH` included that new directory, the matching Mathlib/dependency
  cache, and the standard toolchain. No prior research-package outputs or
  local substitute Mathlib modules were included.

The environment needs a process-path compatibility preload to locate the
installed Lean runtime. The reviewed shim redirects the compiler's own
`/proc/<pid>/exe` lookup to `/proc/self/exe`; it does not change Lean's kernel.
The ordinary Elan/Lake build instructions do not need this environment shim.

## Commands and results

For each module in order:

```text
lean -o .validation-build/<module>.olean <module>.lean
```

| Module | Result |
|---|---|
| PositivityPremise/Kernel | PASS |
| PositivityPremise/Scalar | PASS |
| PositivityPremise/Series | PASS |
| PositivityPremise/Tail | PASS |
| PositivityPremise/LiteralZeta | PASS |
| PositivityPremise | PASS |
| Audit (`lean Audit.lean`) | PASS |

There is one naming-only linter warning: the declaration
`PositivityPremise.PositivityPremise` repeats its namespace. No diagnostic
was suppressed, and there were no compilation errors.

The full default Lake dependency download/bootstrap was not rerun: the
matching cache was already available. `run.sh` provides the standard Lake
build/audit commands; the new `run.cmd` calls native Lean using existing caches.

## Logical-dependency audit

All 22 audited declarations list only:

```text
propext, Classical.choice, Quot.sound
```

No audited theorem depends on `sorryAx` or any added research axiom.
The package contains no `sorry`, `admit`, axiom declaration, or native
evaluation proof. A source scan and the actual `#print axioms` output were
both checked.

This audit does not discharge theorem arguments. In particular, summability,
the complete zeta binding, and the central trace identity remain explicit
inputs; POSITIVITY-PREMISE itself has not been proved for actual zeta zeros.

An independent read-only review found the kernel bounds, pair factor,
height quantifiers, tail decomposition, xi normalization, and literal-RH
adapter consistent with the stated mathematics.

`validation.json` records each source hash and exit status. `build.log`
contains the compilation results; `axioms.log` contains theorem signatures,
the analytic interfaces, and the complete logical-dependency audit.
